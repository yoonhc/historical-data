import json
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

import pytest
from marketdata import backup
from marketdata.domain import json_bytes, sha256
from test_checkpoint_schedule import prepared as prepared  # noqa: F401
from test_checkpoint_schedule import ready as ready  # noqa: F401
from test_checkpoint_schedule import setup_archive as setup_archive  # noqa: F401
from test_restic_archive import write_profile
from test_retirement_clock import Samples, provider

from scripts import archive_backups as archive
from scripts import clock_retirement as safe
from scripts import render_retirement_units
from scripts import retire_checkpoints as retention
from scripts import retirement_clock as clock


@pytest.fixture
def case(prepared, tmp_path, monkeypatch):
    p, policy, _, _, wall, daily = prepared
    monkeypatch.setattr(safe, "now", lambda: wall[0])
    s = Samples(wall[0].timestamp(), mono=1000000)
    real_guard = clock.Guard
    guards = []

    def guard(query, path):
        value = real_guard(query, path, sampler=s)
        guards.append(value)
        return value

    monkeypatch.setattr(clock, "Guard", guard)
    units = tmp_path / "units"
    units.mkdir()
    for name, content in render_retirement_units.render(
        "/opt/test",
        "/etc/test/settings.toml",
        "/var/lib/test",
        {k: str(v) for k, v in vars(p).items()},
    ).items():
        (units / name).write_text(content)
    binding = tmp_path / "binding.json"
    binding.write_bytes(
        json_bytes(
            {"bootstrap_profile": "/etc/test/bootstrap.json", "bootstrap_profile_sha256": "c" * 64}
        )
    )
    settings = safe.Settings(
        tmp_path / "policy.toml",
        tmp_path / "recurring.json",
        tmp_path / "manual.json",
        binding,
        tmp_path / "t05-state",
        units,
    )
    write_profile(settings.retention_policy, policy)
    settings.authorization_file.write_bytes(json_bytes(safe.proposal(settings)))

    class FakeHost:
        def __init__(self, binding):
            self.binding = binding

        @contextmanager
        def lock(self):
            yield self

        def query(self):
            return provider(s, age=900)

    return p, policy, settings, wall, s, real_guard, guards, FakeHost


def cold(case):
    p, _, settings, _, _, _, _, host = case
    return safe.execute(settings, "preview", host_factory=host)


def seed_old_verified_observations(case):
    p, _, settings, _, _, real_guard, _, _ = case
    s = Samples(datetime(2024, 1, 3, 5, tzinfo=UTC).timestamp(), mono=1000)
    guard = real_guard(lambda: provider(s), settings.state_root / "seed-clock.jsonl", sampler=s)
    settings.state_root.mkdir(parents=True, exist_ok=True)
    observation = guard.check(fresh=True)
    witnesses = safe.Witnesses(settings.state_root / "completion-witnesses", p.identity)
    for record in archive.load_state(p)["checkpoints"].values():
        e = record["entry"]
        if e["checkpoint_at"][:10] in {"2024-01-01", "2024-01-02"}:
            assert archive.timestamp(e["completed_at"]).timestamp() < s.wall
            witnesses.observe(e, record["stored"]["snapshot_id"], observation, "d" * 64)


def approve_manual(settings, plan, *, resume=False):
    value = safe.manual_proposal(settings, plan["plan_id"], resume=resume)
    value.update(
        enabled=True,
        approved_at=safe.now(),
        approval_reference="isolated exact-plan approval",
        action="apply-plan",
        grant_kind="exact_plan",
        approved_boot_id=clock.boot_id(),
        resume_interrupted=resume,
        plan_id=plan["plan_id"],
    )
    settings.manual_authorization_file.write_bytes(json_bytes(value))


def allow_test_system_context(monkeypatch):
    # These injected ownership/manager providers belong only to isolated
    # temporary repositories. Real manager provenance is a separate root probe.
    monkeypatch.setattr(clock, "trusted", lambda p, **k: Path(p))
    monkeypatch.setattr(safe, "installed_service", lambda *a: None)
    monkeypatch.setattr(
        safe,
        "system_context",
        lambda s, t: {
            "manager": "system",
            "service_verified": True,
            "scheduled": False,
            "classification": "manual_service_or_unknown",
            "start_job": {"activation_details": {}},
        },
    )


def test_cold_and_warm_preview_preserve_operating_inputs_and_old_grants(case, monkeypatch):
    p, _, settings, _, _, _, _, host = case
    before = {str(f): sha256(f.read_bytes()) for f in p.backup_dir.glob("*/*/backup.json")}
    archived = p.state_file.read_bytes()
    first, second = cold(case), cold(case)
    assert first["state"] == second["state"] == "no_candidates", first
    assert first["plan_id"] != second["plan_id"]
    assert (
        len(first["plan"]["keep"]) == 5
        and len(first["plan"]["clock_safety"]["completion_bounds"]) == 5
    )
    assert first["plan"]["clock_safety"]["observation"]["reference_age_seconds"] == 900
    assert all(
        "completion_upper_bound_less_than_72h" in e["protection"] for e in first["plan"]["keep"]
    )
    assert p.state_file.read_bytes() == archived
    assert before == {str(f): sha256(f.read_bytes()) for f in p.backup_dir.glob("*/*/backup.json")}
    assert not first["deletion_attempted"]
    old = safe.proposal(settings)
    old["purpose"] = safe.legacy.PURPOSE
    settings.authorization_file.write_bytes(json_bytes(old))
    allow_test_system_context(monkeypatch)
    denied = safe.execute(settings, "run", host_factory=host)
    assert denied["reason"] == "authorization_scope_changed" and not denied["deletion_attempted"]


def test_manual_approval_deletes_only_proven_candidates_and_preserves_restic(case, monkeypatch):
    p, _, settings, _, _, _, _, host = case
    seed_old_verified_observations(case)
    preview = cold(case)
    assert preview["state"] == "preview_ready", preview
    plan = preview["plan"]
    assert len(plan["candidates"]) == 2 and len(plan["keep"]) == 3
    archived = p.state_file.read_bytes()
    raw = {
        str(f): sha256(f.read_bytes()) for f in (p.store_root / "data").rglob("*") if f.is_file()
    }
    allow_test_system_context(monkeypatch)
    no_approval = safe.execute(settings, "apply-plan", plan["plan_id"], host_factory=host)
    assert no_approval["state"] == "deferred" and not no_approval["deletion_attempted"]
    approve_manual(settings, plan)
    # A one-plan approval cannot become a recurring grant by copying its file.
    recurring = settings.authorization_file.read_bytes()
    settings.authorization_file.write_bytes(settings.manual_authorization_file.read_bytes())
    denied = safe.execute(settings, "run", host_factory=host)
    assert denied["reason"] == "authorization_scope_changed" and not denied["deletion_attempted"]
    settings.authorization_file.write_bytes(recurring)
    result = safe.execute(settings, "apply-plan", plan["plan_id"], host_factory=host)
    assert result["state"] == "complete" and result["deleted_checkpoints"] == 2, result
    assert all(not Path(c["entry"]["path"]).exists() for c in plan["candidates"])
    assert all(backup.verify_backup(e["path"])["ok"] for e in plan["keep"])
    assert raw == {
        str(f): sha256(f.read_bytes()) for f in (p.store_root / "data").rglob("*") if f.is_file()
    }
    assert archived == p.state_file.read_bytes()
    later = cold(case)
    assert later["state"] == "no_candidates", later
    # The new state namespace still reconciles previously deleted checkpoints
    # with the unchanged archive state and the durable new journals.
    assert len(later["plan"]["keep"]) == 3
    repeated = safe.execute(settings, "apply-plan", plan["plan_id"], host_factory=host)
    assert repeated["state"] == "complete" and repeated["result"]["already_complete"], repeated
    assert repeated["already_complete"] and repeated["deleted_this_run"] == 0
    assert result["deleted_this_run"] == 2


def test_mid_deletion_clock_fault_leaves_journal_and_blocks_new_plan(case, monkeypatch):
    p, _, settings, _, samples, _, _, host = case
    seed_old_verified_observations(case)
    plan = cold(case)["plan"]
    approve_manual(settings, plan)
    allow_test_system_context(monkeypatch)
    original = retention.Retirement.retire_item

    def inject(self, journal, item, hook):
        def fault(phase, target):
            hook(phase, target)
            if phase == "after_move":
                samples.wall += 41

        return original(self, journal, item, fault)

    monkeypatch.setattr(retention.Retirement, "retire_item", inject)
    result = safe.execute(settings, "apply-plan", plan["plan_id"], host_factory=host)
    assert result["state"] == "failed" and result["unfinished_retirement"], result
    journal = json.loads(Path(result["retirement_journal"]).read_bytes())
    assert sum(i["unlinked_files"] for i in journal["items"].values()) == 0
    next_run = cold(case)
    assert next_run["state"] == "deferred" and next_run["reason"] == "unfinished_retirement", (
        next_run
    )
    assert next_run["needs_attention"]
    # Reviewing the existing plan and issuing an explicit recovery approval
    # permits only that plan's remainder; old records are never reset/deleted.
    monkeypatch.setattr(retention.Retirement, "retire_item", original)
    approve_manual(settings, plan, resume=True)
    resumed = safe.execute(settings, "apply-plan", plan["plan_id"], host_factory=host)
    assert resumed["state"] == "complete", resumed
    new_journal = json.loads(Path(resumed["retirement_journal"]).read_bytes())
    assert len(new_journal["attempts"]) == 2
    assert not new_journal["attempts"][0]["ok"] and new_journal["attempts"][1]["ok"]


def test_changed_completion_evidence_and_targets_refuse_application(case, monkeypatch):
    _, _, settings, _, _, _, _, host = case
    seed_old_verified_observations(case)
    plan = cold(case)["plan"]
    approve_manual(settings, plan)
    allow_test_system_context(monkeypatch)
    proof = next(iter(plan["clock_safety"]["completion_bounds"].values()))
    path = Path(proof["file"])
    original = path.read_bytes()
    path.write_bytes(original + b" ")
    result = safe.execute(settings, "apply-plan", plan["plan_id"], host_factory=host)
    assert result["state"] == "failed" and not result["deletion_attempted"], result
    path.write_bytes(original)
    value = json.loads(settings.manual_authorization_file.read_bytes())
    value["plan_id"] = "f" * 64
    settings.manual_authorization_file.write_bytes(json_bytes(value))
    result = safe.execute(settings, "apply-plan", plan["plan_id"], host_factory=host)
    assert result["state"] == "failed" and not result["deletion_attempted"], result
